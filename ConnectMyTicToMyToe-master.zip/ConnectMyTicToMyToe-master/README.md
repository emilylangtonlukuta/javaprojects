# ConnectMyTicToMyToe
 This is a console based game app that allows you to play both TicTacToe and Connect4.
